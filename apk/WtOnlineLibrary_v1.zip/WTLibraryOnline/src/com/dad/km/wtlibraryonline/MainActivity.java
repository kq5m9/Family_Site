package com.dad.km.wtlibraryonline;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.Menu;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

	private WebView webViewer;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		// Setup webViewer
		webViewer = (WebView) findViewById(R.id.webView1);
		webViewer.getSettings().setBuiltInZoomControls(true);
		webViewer.getSettings().setJavaScriptEnabled(true);
		webViewer.setWebViewClient(new MyWebViewClient());
		webViewer.loadUrl("http://wol.jw.org/en/wol/h/r1/lp-e");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// if back button hit and viewer has web history, go back
		if ((keyCode == KeyEvent.KEYCODE_BACK) && (webViewer.canGoBack())) {
			webViewer.goBack();
			return true;
		}
		// otherwise let super handle it
		return super.onKeyDown(keyCode, event);
	}
	
	private class MyWebViewClient extends WebViewClient {
	    @Override
	    public boolean shouldOverrideUrlLoading(WebView view, String url) {
	        if (Uri.parse(url).getHost().equals("wol.jw.org")) {
	            // This is a online library page, so let my WebView load the page
	            return false;
	        }
	        // Otherwise, launch another Activity that handles URLs
	        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
	        startActivity(intent);
	        return true;
	    }
	}

}
