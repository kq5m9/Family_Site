package com.dad.km.wtlibraryonline;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.DownloadListener;
import android.webkit.WebBackForwardList;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;

public class MainActivity extends Activity implements OnClickListener {

	private WebView webViewer;
	private Button siteBtn;
	private Boolean isWtLib = true;
	private String initLib = "http://m.wol.jw.org/en/wol/h/r1/lp-e";
	private String initJW = "http://www.jw.org";
	private String lastLib = initLib, lastJW = initJW;
	private ProgressBar progress;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		// setup progress bar
		progress = (ProgressBar) findViewById(R.id.loadingBar);

		// Setup webViewer
		webViewer = (WebView) findViewById(R.id.webView1);
		webViewer.getSettings().setBuiltInZoomControls(true);
		webViewer.getSettings().setJavaScriptEnabled(true);
		webViewer.getSettings().setDomStorageEnabled(true);
		webViewer.setWebViewClient(new MyWebViewClient());
		webViewer.setWebChromeClient(new MyWebChromeClient());
		webViewer.setDownloadListener(new DownloadListener() {
			public void onDownloadStart(String url, String userAgent,
					String contentDisposition, String mimetype,
					long contentLength) {
				Intent i = new Intent(Intent.ACTION_VIEW);
				i.setData(Uri.parse(url));
				startActivity(i);
			}
		});

		webViewer.loadUrl(initLib);

		// setup Button
		siteBtn = (Button) findViewById(R.id.btnSite);
		siteBtn.setOnClickListener(this);
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// if back button hit and viewer has web history, go back
		if ((keyCode == KeyEvent.KEYCODE_BACK) && (webViewer.canGoBack())) {
			WebBackForwardList wbfl = webViewer.copyBackForwardList();
			String url = wbfl.getItemAtIndex(wbfl.getCurrentIndex()-1).getUrl();
			String host = Uri.parse(url).getHost();
			if (host.endsWith(".jw.org")) {
				isWtLib = host.endsWith("wol.jw.org");
				if (isWtLib) {
					siteBtn.setText(R.string.siteJW);
				} else {
	        		siteBtn.setText(R.string.siteLib);
				}
			}
			webViewer.goBack();
			return true;
		}
		// otherwise let super handle it
		return super.onKeyDown(keyCode, event);
	}
	
	
	private class MyWebChromeClient extends WebChromeClient {
		@Override
		public void onProgressChanged (WebView view, int newProgress)  {
			progress.setProgress(newProgress);
			super.onProgressChanged(view, newProgress);
		}
	}
	
	
	private class MyWebViewClient extends WebViewClient {
		@Override
	    public boolean shouldOverrideUrlLoading(WebView view, String url) {
	    	String host = Uri.parse(url).getHost();
        	Log.e("URLloading", host);
	        if (host.endsWith(".jw.org")) {
	        	// log as either lastJW or lastLib
	        	if (host.endsWith("wol.jw.org")) {
	        		lastLib = url;
	        	} else {
	        		lastJW = url;
	        	}
	            // This is a society page, so let my WebView load the page
	            return false;
	        }
	        // Otherwise, launch another Activity that handles URLs
	        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
	        startActivity(intent);
	        return true;
	    }
	    
		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon) {
			progress.setVisibility(View.VISIBLE);
			progress.setProgress(0);
			super.onPageStarted(view, url, favicon);
		}

		@Override
		public void onPageFinished(WebView view, String url) {
			progress.setVisibility(View.GONE);
			progress.setProgress(100);
			super.onPageFinished(view, url);
		}

	}

	@Override
	public void onClick(View v) {
		// make sure it is siteBtn that was clicked
		if (v == (View) siteBtn) {
			if (isWtLib) {
				Log.e("BtnClicked", "changing to JW.org - " + lastJW);
				siteBtn.setText(R.string.siteLib);
				webViewer.loadUrl(lastJW);
			} else {
				Log.e("BtnClicked", "changing to Wt Lib - " + lastLib);
				siteBtn.setText(R.string.siteJW);
				webViewer.loadUrl(lastLib);
			}
			isWtLib = !isWtLib;
		}
	}

}
