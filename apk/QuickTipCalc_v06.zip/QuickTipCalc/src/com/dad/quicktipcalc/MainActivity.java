package com.dad.quicktipcalc;

import android.os.Bundle;
import android.app.Activity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class MainActivity extends Activity implements OnClickListener,
		OnSeekBarChangeListener, OnFocusChangeListener, TextWatcher {

	// references to layout components
	private Button clearBtn;
	private EditText billET;
	private EditText percentET;
	private EditText tipET;
	private EditText totalET;
	private SeekBar percentSB;

	// private variables
	// sets minimum percentage for slider
	private int minPercent = 5;
	// sets maximum percentage for slider
	private int maxPercent = 35;
	// sets change of EditText field as from user vs programmed
	private boolean isFromUser = true;
	// tracks which EditText field is active
	private EditText activeET = null;
	private String activeETname = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// initialize references to layout components
		clearBtn = (Button) findViewById(R.id.ClearButton1);
		billET = (EditText) findViewById(R.id.BillEditText);
		tipET = (EditText) findViewById(R.id.TipEditText);
		totalET = (EditText) findViewById(R.id.TotalEditText);
		percentSB = (SeekBar) findViewById(R.id.PercentSeekBar);
		percentSB.setProgress(percentSB.getMax() / 2);
		percentET = (EditText) findViewById(R.id.PercentEditText);
		clearBtn.setEnabled(true);

		// 		set active listeners
		billET.addTextChangedListener(this);
		billET.setOnFocusChangeListener(this);
		percentET.addTextChangedListener(this);
		percentET.setOnFocusChangeListener(this);
		tipET.addTextChangedListener(this);
		tipET.setOnFocusChangeListener(this);
		totalET.addTextChangedListener(this);
		totalET.setOnFocusChangeListener(this);
		percentSB.setOnSeekBarChangeListener(this);
		clearBtn.setOnClickListener(this);

		// set all fields to default conditions by 'hitting' clear
		onClick((View) clearBtn);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	
	
	@Override
	public void onFocusChange(View arg0, boolean arg1) {
		activeET = (EditText) arg0;
		activeET.selectAll();
	}
	
@Override
	public void onClick(View arg0) {
		Log.d("clearBtn.onClick","arg0 = " + arg0.toString());
		// if clear button is clicked set all fields to their default conditions
		if (arg0 == clearBtn) {
			isFromUser = false;
			percentSB.setMax(maxPercent - minPercent);
			percentSB.setProgress((maxPercent - minPercent) / 2);
			percentET.setText(Integer.toString(minPercent + percentSB.getProgress()));
			billET.setText(null);
			tipET.setText(null);
			totalET.setText(null);
			billET.requestFocus();
			activeET = billET;
			activeETname = "billET";
			isFromUser = true;
		}
	}

	@Override
	public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
		// only update when changes are from user
		if (isFromUser) {
			// check each EditText field to see who has focus
			activeET = null;
			activeETname = null;
			if (billET.hasFocus()) {
				activeET = billET;
				activeETname = "billET";
			}
			if (percentET.hasFocus()) {
				activeET = percentET;
				activeETname = "percentET";
			}
			if (tipET.hasFocus()) {
				activeET = tipET;
				activeETname = "tipET";
			}
			if (totalET.hasFocus()) {
				activeET = totalET;
				activeETname = "totalET";
			}
			Log.d("onTextChange", activeETname + " has focus.");
			updateAmounts();
		}
	}

	@Override
	public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
		// if slider has been changed by user,
		// update tip percentage field and recalculate amounts
		if (fromUser) {
			isFromUser = false;
			percentET.setText(Integer.toString(progress + minPercent));
			percentET.requestFocus();
			activeET = percentET;
			activeETname = "percentET";
			isFromUser = true;
			updateAmounts();
		}
	}

	private void updateAmounts() {
		// read all EditText values
		int billCents = (int) (readETasDouble(billET) * 100);
		double percent = readETasDouble(percentET);
		int tipCents = (int) (readETasDouble(tipET) * 100);
		int totalCents = (int) (readETasDouble(totalET) * 100);
		
		// log initial values for debugging
		Log.d("initial_values", Integer.toString(billCents) + " - " + Double.toString(percent) + 
				" - " + Integer.toString(tipCents) + " - " + Integer.toString(totalCents) + " - " +
				Integer.toString((int) Math.round(percent - minPercent)));

		// if tip amount is not active, calculate tip amount
		if (activeET != tipET) {
			tipCents = (int) Math.round(billCents * percent / 100);
			if (activeET == totalET) {
				tipCents = totalCents - billCents;
			}
			if (tipCents < 0) {
				tipCents = 0;
			}
		}
		
		// if tip or total are active, calculate percentage
		if ((activeET == tipET) || (activeET == totalET)) {
			percent = 0;
			if (billCents > 0) {
				percent = (float) (100.0 * tipCents / billCents);
				// round resulting percentage
				percent = Math.round(percent * (Math.pow(10, 5))) / Math.pow(10, 5);
			}
		}
		
		// if slider does not match percent, correct slider position
		if (Math.round(percent) != percentSB.getProgress() + minPercent) {
			percentSB.setProgress((int) Math.round(percent - minPercent));
		}
		
		// if total is not active, calculate total
		if (activeET != totalET) {
			totalCents = billCents + tipCents;
		}
		
		// write values back to EditText components, excluding active field
		isFromUser = false;
		if (activeET != percentET) {
			percentET.setText(Double.toString(percent));
		}
		if (activeET != tipET) {
			tipET.setText(String.format("%.2f", (tipCents / 100.0)));
		}
		if (activeET != totalET) {
			totalET.setText(String.format("%.2f", (totalCents / 100.0)));
		}
		isFromUser = true;

		// log new values for debugging
		Log.d("changed_values", Integer.toString(billCents) + " - " + Double.toString(percent) + 
				" - " + Integer.toString(tipCents) + " - " + Integer.toString(totalCents) + " - " +
				Integer.toString((int) Math.round(percent - minPercent)));
	}

	private double readETasDouble(EditText ETfield) {
		// reads EditText field and returns the value as a float.
		String txt = ETfield.getText().toString();
		// if there is no text use zero
		if (txt.length() < 1) {
			txt = "0";
		}
		// try to parse text as a float
		double dbl;
		try {
			dbl = Double.parseDouble(txt);
		} catch (NumberFormatException nfe) {
			dbl = 0.0;
		}
		// return float result
		return dbl;
	}
	

	// stubbed methods
	@Override
	public void onStartTrackingTouch(SeekBar seekBar) {
		// TODO Auto-generated method stub
	}
	@Override
	public void onStopTrackingTouch(SeekBar seekBar) {
		// TODO Auto-generated method stub
	}
	@Override
	public void afterTextChanged(Editable arg0) {
		// TODO Auto-generated method stub
	}
	@Override
	public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
			int arg3) {
		// TODO Auto-generated method stub
		
	}


	
}
